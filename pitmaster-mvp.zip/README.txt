
Pit Master MVP

Как использовать:

1. Загрузите этот сайт на Vercel
2. Или откройте index.html

Заказы будут приходить в Telegram.
